package com.example.hoshban.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.hoshban.data.LinkConfig
import com.example.hoshban.data.LinkRepository
import com.example.hoshban.network.LinkExecutor
import com.example.hoshban.utils.LocaleHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: LinkRepository) : ViewModel() {
    private val _links = MutableStateFlow<List<LinkConfig>>(emptyList())
    val links: StateFlow<List<LinkConfig>> = _links.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(LocaleHelper.getCurrentLanguage())
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _snackbar = MutableStateFlow<String?>(null)
    val snackbar: StateFlow<String?> = _snackbar.asStateFlow()

    init {
        viewModelScope.launch {
            repository.linksFlow.collect { _links.value = it }
        }
    }

    fun setLanguage(lang: String) { _selectedLanguage.value = lang }

    fun addLink(link: LinkConfig) = viewModelScope.launch {
        val updated = _links.value + link
        _links.value = updated
        repository.saveAll(updated)
    }
    fun updateLink(link: LinkConfig) = viewModelScope.launch {
        val updated = _links.value.map { if (it.id == link.id) link else it }
        _links.value = updated
        repository.saveAll(updated)
    }
    fun deleteLink(id: String) = viewModelScope.launch {
        val updated = _links.value.filterNot { it.id == id }
        _links.value = updated
        repository.saveAll(updated)
    }
    fun execute(link: LinkConfig) = viewModelScope.launch {
        val ok = LinkExecutor.execute(link)
        _snackbar.value = if (ok) "✅ درخواست ارسال شد" else "❌ خطا در ارسال"
    }
    fun clearSnackbar() { _snackbar.value = null }

    class Factory(private val repository: LinkRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repository) as T
    }
}
