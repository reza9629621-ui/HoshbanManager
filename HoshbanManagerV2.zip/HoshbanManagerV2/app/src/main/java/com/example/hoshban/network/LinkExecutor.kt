package com.example.hoshban.network

import com.example.hoshban.data.LinkConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object LinkExecutor {
    suspend fun execute(config: LinkConfig): Boolean = withContext(Dispatchers.IO) {
        try {
            val urlString = "https://hoshban.ir/gps/user/save_session.php?Code_system=\${config.codeSystem}&email=\${config.email}"
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            val responseCode = connection.responseCode
            connection.disconnect()
            responseCode in 200..299
        } catch (e: Exception) { e.printStackTrace(); false }
    }
}
