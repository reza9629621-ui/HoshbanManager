package com.example.hoshban.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val LightColors = lightColorScheme(
    primary = Primary, onPrimary = Color.White, primaryContainer = PrimaryLight, onPrimaryContainer = Color.White,
    secondary = Secondary, onSecondary = Color.White, background = Background, onBackground = TextPrimary,
    surface = Surface, onSurface = TextPrimary, error = ErrorRed, onError = Color.White
)
@Composable
fun HoshbanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, typography = AppTypography, content = content)
}
