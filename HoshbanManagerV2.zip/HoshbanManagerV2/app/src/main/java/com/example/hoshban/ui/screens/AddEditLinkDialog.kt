package com.example.hoshban.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.hoshban.data.LinkConfig
import java.util.UUID

@Composable
fun AddEditLinkDialog(existing: LinkConfig?, onDismiss: () -> Unit, onSave: (LinkConfig) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var codeSystem by remember { mutableStateOf(existing?.codeSystem ?: "") }
    var email by remember { mutableStateOf(existing?.email ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss, shape = RoundedCornerShape(24.dp),
        title = { Text(if (existing == null) "افزودن لینک جدید" else "ویرایش لینک", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it; error = null }, label = { Text("نام") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = codeSystem, onValueChange = { codeSystem = it; error = null }, label = { Text("Code_system") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = email, onValueChange = { email = it; error = null }, label = { Text("ایمیل") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank() || codeSystem.isBlank() || email.isBlank()) error = "همه فیلدها الزامیست"
                else onSave(LinkConfig(existing?.id ?: UUID.randomUUID().toString(), name.trim(), codeSystem.trim(), email.trim()))
            }, shape = RoundedCornerShape(12.dp)) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
