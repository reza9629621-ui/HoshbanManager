package com.example.hoshban.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hoshban.data.LinkConfig
import com.example.hoshban.ui.theme.PrimaryDark
import com.example.hoshban.ui.theme.PrimaryLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    links: List<LinkConfig>, snackbar: String?,
    onAdd: (LinkConfig) -> Unit, onUpdate: (LinkConfig) -> Unit, onDelete: (String) -> Unit,
    onExecute: (LinkConfig) -> Unit, onSnackbarShown: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingLink by remember { mutableStateOf<LinkConfig?>(null) }
    var deletingLink by remember { mutableStateOf<LinkConfig?>(null) }

    LaunchedEffect(snackbar) { if (snackbar != null) { snackbarHostState.showSnackbar(snackbar); onSnackbarShown() } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(PrimaryDark, PrimaryLight))).statusBarsPadding().padding(24.dp)) {
                Column {
                    Text("Hoshban Manager V2", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("نسخه اصلاح شده", color = Color.White.copy(0.8f), fontSize = 16.sp)
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAddDialog = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("افزودن لینک")
            }
        }
    ) { padding ->
        if (links.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز لینکی اضافه نکرده‌اید") }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(links, key = { it.id }) { link ->
                    Card(shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(6.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(link.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Code: \${link.codeSystem}", fontSize = 13.sp)
                            Text("Email: \${link.email}", fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onExecute(link) }, modifier = Modifier.weight(1f)) { Text("اجرا") }
                                IconButton(onClick = { editingLink = link }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = { deletingLink = link }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) AddEditLinkDialog(null, { showAddDialog = false }, { onAdd(it); showAddDialog = false })
    editingLink?.let { AddEditLinkDialog(it, { editingLink = null }, { onUpdate(it); editingLink = null }) }
    deletingLink?.let { link ->
        AlertDialog(
            onDismissRequest = { deletingLink = null }, title = { Text("حذف") }, text = { Text("مطمئنید؟") },
            confirmButton = { TextButton(onClick = { onDelete(link.id); deletingLink = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { deletingLink = null }) { Text("انصراف") } }
        )
    }
}
