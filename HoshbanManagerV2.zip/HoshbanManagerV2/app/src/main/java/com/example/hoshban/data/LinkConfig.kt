package com.example.hoshban.data
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class LinkConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val codeSystem: String,
    val email: String
)
