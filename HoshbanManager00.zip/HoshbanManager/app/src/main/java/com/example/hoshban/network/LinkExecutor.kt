package com.example.hoshban.network

import com.example.hoshban.data.LinkConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LinkExecutor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun execute(config: LinkConfig): Boolean = withContext(Dispatchers.IO) {
        try {
            // رفع مشکل %40 : ساخت لینک به صورت متنی تا @ به صورت خام ارسال شود
            val urlString = "https://hoshban.ir/gps/user/save_session.php?Code_system=${config.codeSystem}&email=${config.email}"
            
            val request = Request.Builder().url(urlString).get().build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
