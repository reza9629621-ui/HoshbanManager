package com.example.hoshban.ui.theme

import androidx.compose.ui.graphics.Color

val Primary       = Color(0xFF1E6F5C)
val PrimaryDark   = Color(0xFF0F4C3A)
val PrimaryLight  = Color(0xFF4CAF8F)
val Secondary     = Color(0xFFF2A65A)
val Background    = Color(0xFFF7F9FC)
val Surface       = Color(0xFFFFFFFF)
val ErrorRed      = Color(0xFFD32F2F)
val TextPrimary   = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF6B7280)
