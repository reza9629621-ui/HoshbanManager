package com.example.hoshban

import android.app.Application

class HoshbanApp : Application()
