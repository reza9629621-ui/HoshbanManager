package com.example.hoshban.network

import com.example.hoshban.data.LinkConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LinkExecutor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun execute(config: LinkConfig): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = "https://hoshban.ir/gps/user/save_session.php".toHttpUrl().newBuilder()
                .addQueryParameter("Code_system", config.codeSystem)
                .addQueryParameter("email", config.email)
                .build()
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
