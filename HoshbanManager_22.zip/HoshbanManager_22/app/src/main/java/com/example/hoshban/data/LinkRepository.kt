package com.example.hoshban.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "hoshban_prefs")

class LinkRepository(private val context: Context) {
    private val LINKS_KEY = stringPreferencesKey("saved_links")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val linksFlow: Flow<List<LinkConfig>> = context.dataStore.data.map { prefs ->
        val raw = prefs[LINKS_KEY] ?: "[]"
        try { json.decodeFromString<List<LinkConfig>>(raw) }
        catch (e: Exception) { emptyList() }
    }

    suspend fun saveAll(links: List<LinkConfig>) {
        val raw = json.encodeToString(links)
        context.dataStore.edit { it[LINKS_KEY] = raw }
    }
}
