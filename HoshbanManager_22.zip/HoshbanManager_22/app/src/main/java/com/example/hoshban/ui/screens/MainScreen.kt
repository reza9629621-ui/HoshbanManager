package com.example.hoshban.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hoshban.data.LinkConfig
import com.example.hoshban.ui.components.LanguageChips
import com.example.hoshban.ui.components.LinkCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    links: List<LinkConfig>,
    selectedLanguage: String,
    snackbar: String?,
    onLanguageChange: (String) -> Unit,
    onAdd: (LinkConfig) -> Unit,
    onUpdate: (LinkConfig) -> Unit,
    onDelete: (String) -> Unit,
    onExecute: (LinkConfig) -> Unit,
    onSnackbarShown: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingLink   by remember { mutableStateOf<LinkConfig?>(null) }
    var deletingLink  by remember { mutableStateOf<LinkConfig?>(null) }

    LaunchedEffect(snackbar) {
        if (snackbar != null) {
            snackbarHostState.showSnackbar(snackbar)
            onSnackbarShown()
        }
    }

    val filtered = links.filter { it.language == selectedLanguage }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Text(
                    text = "Hoshban Manager",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                LanguageChips(selected = selectedLanguage, onSelect = onLanguageChange)
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("افزودن لینک") },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor   = MaterialTheme.colorScheme.onSecondary
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "برای این زبان لینکی ثبت نشده است",
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(filtered, key = { it.id }) { link ->
                        LinkCard(
                            link      = link,
                            onExecute = { onExecute(link) },
                            onEdit    = { editingLink = link },
                            onDelete  = { deletingLink = link }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditLinkDialog(
            existing = null,
            defaultLanguage = selectedLanguage,
            onDismiss = { showAddDialog = false },
            onSave    = { onAdd(it); showAddDialog = false }
        )
    }
    editingLink?.let { link ->
        AddEditLinkDialog(
            existing = link,
            defaultLanguage = selectedLanguage,
            onDismiss = { editingLink = null },
            onSave    = { onUpdate(it); editingLink = null }
        )
    }
    deletingLink?.let { link ->
        AlertDialog(
            onDismissRequest = { deletingLink = null },
            title = { Text("حذف لینک") },
            text  = { Text("آیا از حذف «${link.name}» مطمئن هستید؟") },
            confirmButton = {
                TextButton(onClick = { onDelete(link.id); deletingLink = null }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingLink = null }) { Text("انصراف") }
            }
        )
    }
}
